import argparse
import json
import gradio as gr
from utils.multi_files import multi_files
from utils.get_any_per import get_any_percentage
from utils.get_by_illusts import get_by_illusts
from utils.get_by_tag import get_json_by_tag
from utils.get_by_user import get_json_by_user
from utils.get_tags_rank import get_tags_rank


def InitArgs():
    parser = argparse.ArgumentParser()
    # 端口允许自定义
    parser.add_argument("-port", type=int, default=8750, help="WebUI's port")
    parser.add_argument("-host",
                        type=str,
                        default="localhost",
                        help="The host of WebUI")
    parser.add_argument("-inbrowser",
                        type=bool,
                        default=True,
                        help="If open in the browser")
    return parser.parse_args()


# 读取ini文件的函数，返回里面的内容，返回键数组，按照顺序来
def read_options(file_name: str) -> list:
    with open(file_name, "r", encoding="utf-8") as f:
        dict = json.loads(f.read())
        return dict


# 创建用户界面
with gr.Blocks() as ROOT:
    gr.Markdown("# Pixiv Get 3")
    gr.Markdown("方便的获取Pixiv的图片数据~")
    with gr.Tab("前置设定"):
        gr.Markdown("自动读取目录下的`options`文件，如果需要修改请直接修改文件")
        user_data = read_options("options.json")
        COOKIE = gr.Textbox(label="用户的Cookie", value=user_data["cookie"])
        USERAGENT = gr.Textbox(label="用户的User Agent",
                               value=user_data["user_agent"])

    with gr.Tab("By Illusts"):
        TARGET = gr.Textbox(label="输入作品页面获取的json地址")
        PROGRESS = gr.TextArea(label="下载结果以及进度", lines=3)
        gr.Button("下载").click(get_by_illusts,
                                      [TARGET, COOKIE, USERAGENT], PROGRESS)
    with gr.Tab("By Tag"):
        TAG = gr.Textbox(label="输入Tag进行提取，不建议输入多个tag")
        PROGRESS1 = gr.TextArea(label="下载进度", lines=3)
        gr.Button("下载").click(get_json_by_tag,
                                       [TAG, COOKIE, USERAGENT], PROGRESS1)

    with gr.Tab("By User"):
        URL = gr.Textbox(label="输入User页面找到的链接")
        PROGRESS2 = gr.TextArea(label="下载进度", lines=3)
        gr.Button("下载").click(get_json_by_user,
                                       [URL, COOKIE, USERAGENT], PROGRESS2)

    with gr.Tab("合并文件"):
        OUTPUT_NAME = gr.Textbox(label="输出文件名", value="Kaede.json", lines=1)
        PROGRESS3 = gr.TextArea(label="合并进度", lines=3)
        gr.Button("开始合并文件").click(multi_files, OUTPUT_NAME, PROGRESS3)

    with gr.Tab("获取某一Tag占比"):
        with gr.Row():
            with gr.Column(scale=1):
                TAG_TMP = gr.Textbox(label="检索的Tag(请保证拼写正确)")
                FILENAME = gr.Textbox(label="检索的文件名称", value="Kaede.json")
                PROGRESS4 = gr.Plot(label="占比数据饼图")
                gr.Button("开始获取占比").click(get_any_percentage,
                                          [TAG_TMP, FILENAME], PROGRESS4)
            with gr.Column(scale=1):
                # 给一些案例
                gr.Examples(
                    [["R-18", "Kaede.json"], ["Arknights", "Kaede.json"],
                     ["ぱんつ", "Kaede.json"], ["制服", "Kaede.json"],
                     ["女の子", "Kaede.json"], ["セーラー服", "Kaede.json"]],
                    [TAG_TMP, FILENAME],
                    PROGRESS4,
                    get_any_percentage,
                    run_on_click=True)

    with gr.Tab("获取Tags排名"):
        FILE_NAME = gr.Textbox(label="检索文件名", value="Kaede.json", lines=1)
        COUNT = gr.Number(label="前多少个，不建议设置太多，请输入整数")
        PROGRESS5 = gr.Plot(label="排名数据", lines=3)
        gr.Button("开始获取排名").click(get_tags_rank, [FILE_NAME, COUNT], PROGRESS5)

if __name__ == "__main__":
    # 获取参数对象
    args = InitArgs()
    ROOT.queue(20).launch(server_port=args.port,
                          server_name=args.host,
                          inbrowser=args.inbrowser)
