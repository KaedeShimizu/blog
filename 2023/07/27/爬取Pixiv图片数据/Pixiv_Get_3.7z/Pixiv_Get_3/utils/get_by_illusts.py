import requests
import json
import time
import gradio as gr

requests.packages.urllib3.disable_warnings()


def get_by_illusts(TARGET: str,
                   COOKIE: str,
                   USER_AGENT: str,
                   progress=gr.Progress()):
    headers = {
        # 根据自己的浏览器情况填写，UA头也是
        "cookie": COOKIE,
        "user-agent": USER_AGENT,
        "referer": TARGET,
    }
    URL = TARGET
    session = requests.get(URL, headers=headers, verify=False)
    JSON = session.json()

    # 创建一个空列表，用来储存json
    empty_arr = []
    # 通过遍历的方式获取所有的id
    for ID in progress.tqdm(JSON["body"], "下载中"):
        # 创建一个临时字典和空字典
        temp_dict: dict = JSON["body"][ID]
        empty_dict: dict = {}
        empty_dict["pid"]: int = int(ID)
        empty_dict["p"] = temp_dict["pageCount"]
        empty_dict["uid"] = temp_dict["userId"]
        empty_dict["title"] = temp_dict["title"]
        empty_dict["author"] = temp_dict["userName"]
        # r18无法判断，这里先随便给一个把
        if "R-18" in temp_dict["tags"]:
            empty_dict["r18"] = 1
        else:
            empty_dict["r18"] = 0
        empty_dict["width"] = temp_dict["width"]
        empty_dict["height"] = temp_dict["height"]
        empty_dict["tags"] = temp_dict["tags"]
        # 通过ID转换为网址
        URL = "https://www.pixiv.net/ajax/illust/" + ID + "/pages?lang=zh"
        # 获取对应的图片链接
        session = requests.get(URL, headers=headers, verify=False)
        JSON1 = session.json()
        empty_dict["url"] = JSON1["body"][0]["urls"]["original"]
        empty_dict["urls"] = JSON1["body"][0]["urls"]
        empty_arr.append(empty_dict)
    # 导出记录完毕的json数据
    with open(f"jsons/{time.time()}.json", "w", encoding="utf-8") as f:
        f.write(json.dumps(empty_arr))