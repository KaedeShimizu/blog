"""
这个文件是用来获取一个json标准库中r18图片占用比例的
如果调用同名函数，会返回一个数组
数组分别是r18数量，非r18数量以及一个占比
"""
import json
import pandas as pd
import altair as alt
import gradio as gr


def get_any_percentage(TAG: str, FILE_NAME: str, progress=gr.Progress()):
    try:
        # 读取目标文件
        with open(f"jsons/{FILE_NAME}", "r", encoding="utf-8") as f:
            # 这个f里面默认是一个大的数组
            ARR = json.loads(f.read())
            # 定义两个临时变量，r18与否
            IS_R18 = 0
            TOTAL = 0
            # 遍历这个文件
            for ITEM in progress.tqdm(ARR, "计算中"):
                if TAG in ITEM["tags"]:
                    IS_R18 += 1
                TOTAL += 1
            # 返回数据
            RESULT = [IS_R18, TOTAL - IS_R18]
            data = [RESULT[0], RESULT[1]]
            # 创建数据
            source = pd.DataFrame({
                "category": [f"{TAG}: {RESULT[0]}", f"非{TAG}: {RESULT[1]}"],
                "value":
                data
            })
            # 创建表格并且返回
            return alt.Chart(source).mark_arc().encode(theta="value",
                                                       color="category")
    except:
        return