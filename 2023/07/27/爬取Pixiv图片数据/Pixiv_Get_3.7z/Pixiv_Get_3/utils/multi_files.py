# 合并文件
# 效率优化版本 读取 存放的时候直接进行判断是否存在就好
import os
import json
import gradio as gr


def multi_files(OUT_NAME: str, progress=gr.Progress()):
    # 额外数据
    addention_final = []
    # 读取pids
    with open("pids.json", 'r', encoding="utf-8") as pid_file:
        pids = json.loads(pid_file.read())

    new_items = 0

    # 遍历存入json文件的文件夹
    for file in os.listdir("jsons"):
        # 判断一下文件名，这里的文件名是不能变的，如果是的话直接跳过这个整合文件
        if file == "Kaede.json":
            continue
        # 读取文件
        with open(f"jsons/{file}", "r", encoding="utf-8") as f:
            # 获取文件数组
            arr = json.loads(f.read())
            for i in progress.tqdm(arr, f"处理{file}中..."):
                # 通过pid判断一下
                if i["pid"] not in pids:
                    # 如果不存在，也就是需要新增一个内容上去
                    # 更新pids列表
                    pids.append(i["pid"])
                    # 额外列表加一个元素
                    addention_final.append(i)
                    # 计数变量增加
                    new_items += 1
        # 删除读取完的文件
        os.remove(f"jsons/{file}")

    # 保存pids文件
    with open("pids.json", 'w', encoding="utf-8") as pid_file:
        pid_file.write(json.dumps(pids))

    # 保存一个额外文件出来
    # 打开标准文件
    with open(f"jsons/{OUT_NAME}", "r", encoding="utf-8") as file:
        data: list = json.loads(file.read())
        # 开始追加内容
        for i in progress.tqdm(addention_final, "追加数据中"):
            data.append(i)
        # 保存数据
        with open(f"jsons/{OUT_NAME}", "w", encoding="utf-8") as F:
            F.write(json.dumps(data))

    return f"完成！新增数量：{new_items}，当前数据量：{len(pids)}"
