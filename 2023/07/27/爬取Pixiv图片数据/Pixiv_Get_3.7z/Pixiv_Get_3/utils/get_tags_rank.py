# 可以遍历一个传入的文件，此文件应当为标准格式文件
# 随后返回一个图标，显示前10名Tags的数量
# 这里的文件必须放在jsons文件夹中

import altair as alt
import pandas as pd
import gradio as gr
import json
from rich import print


def get_tags_rank(file: str, times: int, progress=gr.Progress()):
    """获取传入文件的Tags排名

    Args:
        file (str): 文件名，应当放在jsons文件夹下面
        times (int): 获取的前n个

    Returns:
        _type_: 返回一个图表，alt图标
    """
    times = int(times)
    try:
        with open(f"jsons/{file}", "r", encoding="utf-8") as f:
            # 获取所有的data文件
            data = json.loads(f.read())
            # 创建字典，key-value = Tag-出现次数
            tags_dict = {}
            # 开始遍历这个文件
            for item in progress.tqdm(data, "获取中"):
                # 获取这个item的tags列表，直接遍历
                for tag in item['tags']:
                    # 判断字典是否存储了这个tag
                    if tag in tags_dict:
                        # 在的话直接加一就好
                        tags_dict[tag] += 1
                    else:
                        # 不存在，直接初始化这个键值对
                        tags_dict[tag] = 1
            # 获取完毕，进行排序，从高到低进行排序就好，获取一个列表
            final_list = sorted(tags_dict.items(),
                                key=lambda kv: (kv[1], kv[0]),
                                reverse=True)[:times]
            # 初始化两个新的变量，用来存储tag名和对应数据
            tags_list = []
            count_list = []
            # 遍历数据列表
            for item in final_list:
                tags_list.append(item[0])
                count_list.append(item[1])
            # 创建数据
            source = pd.DataFrame({
                # 设定分类
                "Tags": tags_list,
                "数量": count_list
            })

            # 创建图标
            return alt.Chart(source).mark_bar().encode(y="Tags", x="数量")
    except:
        print("文件不存在或路径错误")