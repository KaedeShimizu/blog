import requests
import time
import json
from urllib.parse import quote
import gradio as gr

requests.packages.urllib3.disable_warnings()


def get_json_by_tag(TAG: str, COOKIE, USERAGENT, progress=gr.Progress()):
    KEYWORD = quote(TAG)
    TARGET = f"https://www.pixiv.net/ajax/search/artworks/{KEYWORD}?word={KEYWORD}&order=date_d&mode=all&p=1&s_mode=s_tag_full&type=all&lang=zh"
    headers = {
        # 根据自己的浏览器情况填写，UA头也是
        "cookie": COOKIE,
        "user-agent": USERAGENT,
        "referer": TARGET,
    }
    session = requests.get(TARGET, headers=headers, verify=False)
    JSON = session.json()

    permanent = JSON["body"]["popular"]["permanent"]

    # 创建一个空列表，用来储存json
    empty_arr = []

    for ITEM in progress.tqdm(permanent, "下载Popular中"):
        try:
            empty_dict: dict = {}
            empty_dict["pid"]: int = int(ITEM["id"])
            empty_dict["p"] = ITEM["pageCount"]
            empty_dict["uid"] = ITEM["userId"]
            empty_dict["title"] = ITEM["title"]
            empty_dict["author"] = ITEM["userName"]
            # r18无法判断，这里先随便给一个把
            if "R-18" in ITEM["tags"]:
                empty_dict["r18"] = 1
            else:
                empty_dict["r18"] = 0
            empty_dict["width"] = ITEM["width"]
            empty_dict["height"] = ITEM["height"]
            empty_dict["tags"] = ITEM["tags"]
            # 通过ID转换为网址
            URL = f"https://www.pixiv.net/ajax/illust/{empty_dict['pid']}/pages?lang = zh"
            # 获取对应的图片链接
            session = requests.get(URL, headers=headers, verify=False)
            JSON1 = session.json()
            empty_dict["url"] = JSON1["body"][0]["urls"]["original"]
            empty_dict["urls"] = JSON1["body"][0]["urls"]
            empty_arr.append(empty_dict)
        except:
            continue
    with open(f"jsons/POPULAR_{time.time()}.json", "w", encoding="utf-8") as f:
        f.write(json.dumps(empty_arr))

    # 另外一个
    recent = JSON["body"]["popular"]["recent"]
    for ITEM in progress.tqdm(recent, "下载Recent中"):
        try:
            empty_dict: dict = {}
            empty_dict["pid"]: int = int(ITEM["id"])
            empty_dict["p"] = ITEM["pageCount"]
            empty_dict["uid"] = ITEM["userId"]
            empty_dict["title"] = ITEM["title"]
            empty_dict["author"] = ITEM["userName"]
            # r18无法判断，这里先随便给一个把
            if "R-18" in ITEM["tags"]:
                empty_dict["r18"] = 1
            else:
                empty_dict["r18"] = 0
            empty_dict["width"] = ITEM["width"]
            empty_dict["height"] = ITEM["height"]
            empty_dict["tags"] = ITEM["tags"]
            # 通过ID转换为网址
            URL = f"https://www.pixiv.net/ajax/illust/{empty_dict['pid']}/pages?lang = zh"
            # 获取对应的图片链接
            session = requests.get(URL, headers=headers, verify=False)
            JSON1 = session.json()
            empty_dict["url"] = JSON1["body"][0]["urls"]["original"]
            empty_dict["urls"] = JSON1["body"][0]["urls"]
            empty_arr.append(empty_dict)
        except:
            continue
    with open(f"jsons/RECENT_{time.time()}.json", "w", encoding="utf-8") as f:
        f.write(json.dumps(empty_arr))
    return "下载完成！"
