# 使用Gradio的话，我觉得直接通过两个界面进行交互会简单很多
# 如果还要涉及到切换可能会出现加载速度缓慢的情况
# 所以我直接通过Tab标签页写两个翻译，同时加载即可

# 导包
from transformers import pipeline, AutoModelWithLMHead, AutoTokenizer
import gradio as gr

# 加载模型
print("加载中-英模型ing...")
model_zh_en = AutoModelWithLMHead.from_pretrained("model/opus-mt-zh-en")
tokenizer_zh_en = AutoTokenizer.from_pretrained("model/opus-mt-zh-en")
translation_zh_en = pipeline(
    "translation_zh_to_en", model=model_zh_en, tokenizer=tokenizer_zh_en)
print("加载完毕！")

print("加载英-中模型ing...")
model_en_zh = AutoModelWithLMHead.from_pretrained("model/opus-mt-en-zh")
tokenizer_en_zh = AutoTokenizer.from_pretrained("model/opus-mt-en-zh")
translation_en_zh = pipeline(
    "translation_en_to_zh", model=model_en_zh, tokenizer=tokenizer_en_zh)
print("加载完成！")

# 翻译函数


def get_translate_zh_en(Itext):
    return translation_zh_en(Itext, max_length=40)[0]['translation_text']


def get_translate_en_zh(Itext):
    return translation_en_zh(Itext, max_length=40)[0]['translation_text']


# 创建界面
print("加载页面中")
with gr.Blocks() as iface:
    gr.Markdown("# 翻译器\nMade by Kaede")
    with gr.Tab("中译英"):
        text_input_zh_en = gr.Textbox(label="需要翻译的内容")
        text_output_zh_en = gr.Textbox(label="翻译后的内容")
        button_zh_en = gr.Button("翻译")
    with gr.Tab("英译中"):
        text_input_en_zh = gr.Textbox(label="需要翻译的内容")
        text_output_en_zh = gr.Textbox(label="翻译后的内容")
        button_en_zh = gr.Button("翻译")

    # 按钮点击事件
    button_zh_en.click(get_translate_zh_en,
                       text_input_zh_en, text_output_zh_en)
    button_en_zh.click(get_translate_en_zh,
                       text_input_en_zh, text_output_en_zh)
iface.launch(inbrowser=True)
print("加载完毕！")
