# 在这里编写加密/解密的各种逻辑
import base64
import urllib.parse

# 64加密


def kaede_encode64(text):
    text = text.encode('utf-8')
    return base64.b64encode(text)

# 64解密


def kaede_decode64(text):
    text = text.encode('utf-8')
    return base64.b64decode(text)

# 32加密


def kaede_encode32(text):
    text = text.encode('utf-8')
    return base64.b32encode(text)

# 32解密


def kaede_decode32(text):
    text = text.encode('utf-8')
    return base64.b32decode(text)

# 16加密


def kaede_encode16(text):
    text = text.encode('utf-8')
    return base64.b16encode(text)

# 16解密


def kaede_decode16(text):
    text = text.encode('utf-8')
    return base64.b16decode(text)

# url encode加密


def kaede_url_encode(text):
    return urllib.parse.quote(text)

# url 解密


def kaede_url_decode(text):
    return urllib.parse.unquote(text)

# unicode编码


def kaede_unicode_encode(text):
    return text.encode('unicode-escape').decode()

# 解码


def kaede_unicode_decode(text):
    return text.encode().decode('unicode-escape')


# 摩斯密码
# 密码本
codes_to_morse = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..',
    'E': '.', 'F': '..-.', 'G': '--.', 'H': '....',
    'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.',
    'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-',
    'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--',
    '4': '....-', '5': '.....', '6': '-....', '7': '--...',
    '8': '---..', '9': '----.',
    '.': '.-.-.-', ':': '---...', ',': '--..--',  ';': '-.-.-.',
    '?': '..--..', '=': '-...-',  '\'': '.----.', '/': '-..-.',
    '!': '-.-.--', '-': '-....-', '_': '..--.-',  '"': '.-..-.',
    '(': '-.--.',  ')': '-.--.-', '$': '...-..-', '&': '....',
    '@': '.--.-.', '+': '.-.-.',
}

morse_to_codes = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G",
    "....": "H", "..": "I", ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N",
    "---": "O", ".--．": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
    "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z",

    "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4",
    ".....": "5", "-....": "6", "--...": "7", "---..": "8", "----.": "9",

    ".-.-.-": ".", "---...": ":", "--..--": ",", "-.-.-.": ";", "..--..": "?",
    "-...-": "=", ".----.": "'", "-..-.": "/", "-.-.--": "!", "-....-": "-",
    "..--.-": "_", ".-..-.": '"', "-.--.": "(", "-.--.-": ")", "...-..-": "$",
    "....": "&", ".--.-.": "@", ".-.-.": "+",
}

# 解密函数
def kaede_morse_decode(string):
    # 分割，字符串string，分割标识符sign
    lists = string.split("/")
    # 给一个零时变量
    output = ""
    for code in lists:
        output += morse_to_codes.get(code)
    # 返回
    return output

# 加密函数
def kaede_morse_encode(words):
    # 临时变量
    output = ""
    for s in words:
        code = codes_to_morse.get(s.upper(), s)
        output += code + "/"
    return output[:-1]

# 凯撒密码
def kaede_encrypt(str, key):
    key = int(key)
    ciphertext=""
    for word in str: 
        if word.isupper():
            ciphertext += chr((ord(word) - 65 + key) % 26 + 65)
        elif word.islower():
            ciphertext += chr((ord(word) - 97 + key) % 26 + 97)
        else:
            ciphertext = ciphertext + word
    return ciphertext

def kaede_decrypt(str, key):
    key = int(key)
    plaintext=""
    for word in str: 
        if word.isupper():
            plaintext += chr((ord(word) - 65 - key) % 26 + 65)
        elif word.islower():
            plaintext += chr((ord(word) - 97 - key) % 26 + 97)
        else:
            plaintext = plaintext + word
    return plaintext