# 这是这个程序的UI界面
import gradio as gr
import Tools as t

# 主界面
with gr.Blocks() as iface:
    # 标题
    gr.Markdown("## 编码/解码器\nmade by Kaede")
    # Base64部分
    with gr.Tab("Base64"):
        # 加密部分
        text_input_encode = gr.Textbox(label="需要加密的内容")
        text_output_encode = gr.Textbox(label="加密后的内容")
        text_button_encode = gr.Button("加密")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="加密的内容")
        text_output_decode = gr.Textbox(label="解密后的内容")
        text_button_decode = gr.Button("解密")

    # 64功能部分
    text_button_encode.click(
        t.kaede_encode64, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_decode64, inputs=text_input_decode, outputs=text_output_decode)

    # Base32部分
    with gr.Tab("Base32"):
        # 加密部分
        text_input_encode = gr.Textbox(label="需要加密的内容")
        text_output_encode = gr.Textbox(label="加密后的内容")
        text_button_encode = gr.Button("加密")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="加密的内容")
        text_output_decode = gr.Textbox(label="解密后的内容")
        text_button_decode = gr.Button("解密")

    # 32功能部分
    text_button_encode.click(
        t.kaede_encode32, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_decode32, inputs=text_input_decode, outputs=text_output_decode)

    # Base16部分
    with gr.Tab("Base16"):
        # 加密部分
        text_input_encode = gr.Textbox(label="需要加密的内容")
        text_output_encode = gr.Textbox(label="加密后的内容")
        text_button_encode = gr.Button("加密")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="加密的内容")
        text_output_decode = gr.Textbox(label="解密后的内容")
        text_button_decode = gr.Button("解密")

    # 32功能部分
    text_button_encode.click(
        t.kaede_encode16, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_decode16, inputs=text_input_decode, outputs=text_output_decode)

    # URL Code部分
    with gr.Tab("Url Code"):
        # 说明
        gr.Markdown("这种加密方式用于网页传递汉字")
        # 加密部分
        text_input_encode = gr.Textbox(label="需要加密的内容")
        text_output_encode = gr.Textbox(label="加密后的内容")
        text_button_encode = gr.Button("加密")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="加密的内容")
        text_output_decode = gr.Textbox(label="解密后的内容")
        text_button_decode = gr.Button("解密")

    # Url Code功能部分
    text_button_encode.click(
        t.kaede_url_encode, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_url_decode, inputs=text_input_decode, outputs=text_output_decode)

    # unicode部分
    with gr.Tab("unicode"):
        # 说明
        gr.Markdown("常用的编码解码")
        # 加密部分
        text_input_encode = gr.Textbox(label="需要编码的内容")
        text_output_encode = gr.Textbox(label="编码后的内容")
        text_button_encode = gr.Button("编码")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="编码的内容")
        text_output_decode = gr.Textbox(label="解码后的内容")
        text_button_decode = gr.Button("解码")

    # Url Code功能部分
    text_button_encode.click(
        t.kaede_unicode_encode, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_unicode_decode, inputs=text_input_decode, outputs=text_output_decode)

    # Morse部分
    with gr.Tab("Morse"):
        gr.Markdown("默认分隔符为`/`，如果需要请修改源代码")
        # 加密部分
        text_input_encode = gr.Textbox(label="需要编码的内容")
        text_output_encode = gr.Textbox(label="编码后的内容")
        text_button_encode = gr.Button("编码")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="编码的内容")
        text_output_decode = gr.Textbox(label="解码后的内容")
        text_button_decode = gr.Button("解码")

    # Morse功能部分
    text_button_encode.click(
        t.kaede_morse_encode, inputs=text_input_encode, outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_morse_decode, inputs=text_input_decode, outputs=text_output_decode)

    # 凯撒密码部分
    with gr.Tab("Caesar"):
        # 加密部分
        text_input_encode = gr.Textbox(label="需要编码的内容")
        number_encode = gr.Number(label="密钥")
        text_output_encode = gr.Textbox(label="编码后的内容")
        text_button_encode = gr.Button("编码")
        gr.Markdown("***")
        # 解密部分
        text_input_decode = gr.Textbox(label="编码的内容")
        number_decode = gr.Number(label="密钥")
        text_output_decode = gr.Textbox(label="解码后的内容")
        text_button_decode = gr.Button("解码")

    # 凯撒密码功能部分
    text_button_encode.click(
        t.kaede_encrypt, inputs=[text_input_encode, number_encode], outputs=text_output_encode)
    text_button_decode.click(
        t.kaede_decrypt, inputs=[text_input_decode, number_decode], outputs=text_output_decode)
    
    with gr.Tab("关于"):
        # 关于部分 一些介绍什么的
        gr.Markdown("# 关于这个程序\n其实就是我随手制作的一个小程序，集合了一些常用的编码解码，方便我个人使用的。\n如果需要，你可以手动修改源代码哦")


# 启动
iface.launch(inbrowser=True)
